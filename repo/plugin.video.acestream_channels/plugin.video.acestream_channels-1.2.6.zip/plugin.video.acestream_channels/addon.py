import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.request
import zipfile
import json
import re 
from urllib.parse import urlencode, parse_qsl, urljoin, quote
import xbmcvfs

# --- CONFIGURACIÓN BASE (Estructura Segura v1.2.4) ---
LIBRARIES_ZIP_URL = "https://github.com/Gunter257/repoachannels/raw/refs/heads/main/bibliotecas.zip"

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

try:
    ADDON.setSetting('addon_initialized_test', 'true')
except Exception as e:
    xbmc.log(f"[Acestream Channels] ERROR: Failed to save initial setting: {e}", xbmc.LOGERROR)

# Rutas
LIBRARIES_ZIP_PATH = os.path.join(PROFILE_PATH, 'bibliotecas.zip') 
LIBRARIES_PATH = os.path.join(PROFILE_PATH, 'lib') 

addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

addon_path = ADDON.getAddonInfo('path')
RESOURCES_PATH = os.path.join(addon_path, 'resources')
ICON_AGENDA = os.path.join(addon_path, 'resources', 'icon.png') 

# --- CONFIGURACIÓN VISUAL Y URLS ---
COLOR_TIME = "FF87CEEB" 
COLOR_SPORT_CATEGORY = "FF32CD32" 
COLOR_YELLOW = "FFFFFF00"
COLOR_GREEN = "FF00FF00"

AGENDA_URLS = [
    "https://eventos-eight-dun.vercel.app/",
    "https://uk.4everproxy.com/secure/KpUm_WoxDYiMMqOAdEZifdMMb0AJKLdAbBX9Yf65kU_CCoqpUvCnHfFaTVnwEkBz"
]

# MENSAJE DE VPN (Se mostrará al inicio)
VPN_WARNING = "AVISO:\n\nPara el correcto funcionamiento de los enlaces, es necesario tener activada una VPN o Cloudflare WARP.\n\nSi los canales no cargan, revisa tu conexión."

CHANGELOG = {
    "1.2.6": [
        "Resueltos los problemas de instalación en Android",
    ]
}

# --- 1. INSTALADOR DE LIBRERÍAS ---
def check_and_install_libraries():
    if not os.path.exists(LIBRARIES_PATH):
        xbmc.log("[Acestream Channels] INFO: Library folder not found. Starting download...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Configurando", "Descargando componentes...", xbmcgui.NOTIFICATION_INFO)
        try:
            if not os.path.exists(PROFILE_PATH):
                os.makedirs(PROFILE_PATH)
            
            urllib.request.urlretrieve(LIBRARIES_ZIP_URL, LIBRARIES_ZIP_PATH)
            
            with zipfile.ZipFile(LIBRARIES_ZIP_PATH, 'r') as zip_ref:
                zip_ref.extractall(LIBRARIES_PATH)
            
            os.remove(LIBRARIES_ZIP_PATH)
            xbmcgui.Dialog().notification("Éxito", "Componentes instalados.", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmc.log(f"[Acestream Channels] ERROR: Failed to download libraries: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", f"Fallo instalación: {e}", xbmc.NOTIFICATION_ERROR)
            return False
    return True

# --- 2. LÓGICA DEL ADDON ---
if check_and_install_libraries():
    sys.path.insert(0, LIBRARIES_PATH)
    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError:
        xbmcgui.Dialog().ok("Reinicio necesario", "Componentes instalados.\nVuelve a abrir el addon.")
        sys.exit()

    # --- FUNCIONES ---

    def build_url(query):
        return BASE_URL + '?' + urlencode(query)

    def clean_text(text):
        if not text: return ""
        return re.sub(r'\s+', ' ', text).strip()

    def get_acestream_id(url):
        if url.startswith("acestream://"):
            return url.replace("acestream://", "")
        return url

    def check_updates():
        last_version = ADDON.getSetting('last_run_version')
        current_version = ADDON.getAddonInfo('version')
        if last_version != current_version:
            changes = CHANGELOG.get(current_version)
            if not changes: changes = CHANGELOG.get("1.2.6") 
            if changes:
                text = f"[B]Novedades v{current_version}:[/B]\n\n" + "\n".join(f"- {i}" for i in changes)
                xbmcgui.Dialog().ok(f"{ADDON_NAME}", text)
            ADDON.setSetting('last_run_version', current_version)

    def show_vpn_alert():
        """Muestra el aviso de VPN"""
        # Usamos .ok para que el usuario tenga que darle a "Aceptar"
        xbmcgui.Dialog().ok("REQUISITO DE CONEXIÓN", VPN_WARNING)

    def fetch_html_content(target_url, index):
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        xbmcgui.Dialog().notification("Agenda", f"Probando servidor {index + 1}...", xbmcgui.NOTIFICATION_INFO, 1000)

        try:
            r = requests.get(target_url, headers=headers, timeout=10)
            if r.status_code == 200: return r.text
        except: pass
        
        try:
            r = requests.get(f"https://api.allorigins.win/get?url={quote(target_url)}", headers=headers, timeout=10)
            if r.status_code == 200 and 'contents' in r.json(): return r.json()['contents']
        except: pass

        try:
            r = requests.get(f"https://corsproxy.io/?{quote(target_url)}", headers=headers, timeout=10)
            if r.status_code == 200: return r.text
        except: pass

        return None

    def list_agenda_events():
        events_found = False
        
        for i, url in enumerate(AGENDA_URLS):
            html_content = fetch_html_content(url, i)
            if not html_content: continue

            try:
                soup = BeautifulSoup(html_content, 'html.parser')
                table = soup.find('table')
                if not table: continue
                
                rows = table.find_all('tr')
                items_count = 0

                for row in rows:
                    cols = row.find_all('td')
                    if not cols or len(cols) < 6: continue 

                    day = clean_text(cols[0].get_text())
                    time = clean_text(cols[1].get_text())
                    sport = clean_text(cols[2].get_text())
                    competition = clean_text(cols[3].get_text())
                    event_name = clean_text(cols[4].get_text())
                    links_col = cols[5]

                    title_display = f"[COLOR {COLOR_TIME}][{time}][/COLOR] [COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] {event_name} [I]({competition})[/I]"
                    
                    links = []
                    for link in links_col.find_all('a'):
                        href = link.get('href', '')
                        if 'acestream://' in href:
                            ace_id = get_acestream_id(href)
                            name = clean_text(link.get_text()).replace('▶', '').strip()
                            links.append({'name': name, 'id': ace_id})

                    if not links: continue
                    items_count += 1

                    if len(links) == 1:
                        ace_id = links[0]['id']
                        url_item = build_url({'action': 'play_channel', 'id': ace_id})
                        li = xbmcgui.ListItem(label=title_display)
                        li.setInfo('video', {'title': event_name, 'mediatype': 'video', 'plot': competition})
                        li.setProperty('IsPlayable', 'true')
                        li.setArt({'icon': 'DefaultVideo.png'}) 
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_item, listitem=li, isFolder=False)
                    else:
                        links_json = json.dumps(links)
                        url_item = build_url({'action': 'list_event_links', 'links': links_json, 'title': event_name})
                        title_display += f" [COLOR {COLOR_YELLOW}]({len(links)} Canales)[/COLOR]"
                        li = xbmcgui.ListItem(label=title_display)
                        li.setInfo('video', {'title': event_name, 'plot': f"Competición: {competition}\nOpciones: {len(links)}"})
                        li.setArt({'icon': 'DefaultFolder.png'})
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_item, listitem=li, isFolder=True)
                
                if items_count > 0:
                    events_found = True
                    break 
                    
            except Exception as e:
                xbmc.log(f"[Acestream Channels] Parse Error: {e}", xbmc.LOGERROR)
                continue
        
        if events_found:
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            # Si falla todo, recordamos el motivo probable (VPN)
            xbmcgui.Dialog().ok("ERROR DE CONEXIÓN", "No se ha podido cargar la agenda.\n\nEs muy probable que tu operador esté bloqueando la web.\n\nPor favor, activa tu VPN o WARP e inténtalo de nuevo.")

    def list_event_links(links_json, event_title):
        try:
            links = json.loads(links_json)
            xbmcplugin.setContent(addon_handle, 'videos')
            for link in links:
                name = link['name']
                ace_id = link['id']
                display_name = f"[COLOR {COLOR_GREEN}]Ver en:[/COLOR] {name}"
                url = build_url({'action': 'play_channel', 'id': ace_id})
                li = xbmcgui.ListItem(label=display_name)
                li.setInfo('video', {'title': event_title, 'mediatype': 'video'})
                li.setProperty('IsPlayable', 'true')
                li.setArt({'icon': 'DefaultVideo.png'})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(addon_handle)
        except Exception as e:
            xbmc.log(f"[Acestream Channels] Error links: {e}", xbmc.LOGERROR)

    def play_channel(url_id):
        try:
            use_external = ADDON.getSetting('use_external_player') == 'true'
            if use_external:
                strm_content = f"http://127.0.0.1:6878/ace/getstream?id={url_id}"
                strm_path = os.path.join(PROFILE_PATH, 'temp_acestream.strm')
                with open(strm_path, 'w') as f: f.write(strm_content)
                xbmc.Player().play(strm_path)
            else:
                horus_url = f"plugin://script.module.horus/?action=play&id={url_id}"
                li = xbmcgui.ListItem(path=horus_url)
                xbmcplugin.setResolvedUrl(addon_handle, True, li)
        except Exception as e:
            xbmcgui.Dialog().notification("Error", f"Fallo al reproducir: {e}", xbmc.NOTIFICATION_ERROR)

    # --- ROUTER PRINCIPAL ---
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get("action")
    
    # 1. SI ESTAMOS EN LA RAÍZ (AL ENTRAR)
    if action is None:
        # Primero revisamos si hay update
        check_updates()
        
        # AQUI MOSTRAMOS EL AVISO DE VPN (Solo al entrar al addon)
        show_vpn_alert()
        
        # Construimos el menú
        url = build_url({'action': 'list_channels', 'category': 'AGENDA'})
        li = xbmcgui.ListItem(label="[B]AGENDA DEPORTIVA[/B]")
        li.setArt({'icon': ICON_AGENDA})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)

    # 2. RESTO DE ACCIONES
    elif action == "list_channels":
        category = args.get("category")
        if category == "AGENDA":
            list_agenda_events()

    elif action == "list_event_links":
        list_event_links(args.get("links"), args.get("title"))

    elif action == "play_channel":
        play_channel(args.get("id"))

else:
    sys.exit()