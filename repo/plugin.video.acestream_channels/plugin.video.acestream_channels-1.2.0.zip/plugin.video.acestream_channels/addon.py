import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.request
import zipfile
import json
from urllib.parse import urlencode, parse_qsl, urljoin
import xbmcvfs

# Configuración para la gestión de dependencias
LIBRARIES_ZIP_URL = "https://github.com/Gunter257/repoachannels/raw/refs/heads/main/bibliotecas.zip"

ADDON = xbmcaddon.Addon()
# Define PROFILE_PATH para que todas las rutas persistentes usen este base
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# La ruta del archivo ZIP descargado se mueve al perfil
LIBRARIES_ZIP_PATH = os.path.join(PROFILE_PATH, 'bibliotecas.zip') 
# Las bibliotecas se guardarán en una subcarpeta 'lib' dentro del perfil
LIBRARIES_PATH = os.path.join(PROFILE_PATH, 'lib') 

# Define el handle del addon
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Obtener la ruta del addon (ruta de instalación, no de perfil)
addon_path = ADDON.getAddonInfo('path')
RESOURCES_PATH = os.path.join(addon_path, 'resources')

# --- Códigos de color Kodi ---
COLOR_ORANGE = "FF00A5FF"      # HEX para naranja (para Canal Eventual)
COLOR_RED = "FFFF0000"         # HEX para rojo para Canal Caído
COLOR_CYAN = "FF00FFFF"        # HEX para cian para Opciones

# --- Configuración para raspado dinámico (NUEVA URL) ---
SCRAPING_URL = "https://www.socialcreator.com/xupimarc2/?s=289267"

# Verificar e instalar bibliotecas si es la primera ejecución
def check_and_install_libraries():
    # Asegurarse de que el directorio de perfil existe antes de intentar crear 'lib' o descargar el zip
    if not os.path.exists(PROFILE_PATH):
        os.makedirs(PROFILE_PATH)

    if not os.path.exists(LIBRARIES_PATH):
        xbmcgui.Dialog().notification("Instalando bibliotecas", "Descargando bibliotecas necesarias...", xbmcgui.NOTIFICATION_INFO)
        try:
            xbmc.log(f"[Acestream Channels] INFO: Attempting to download libraries from: {LIBRARIES_ZIP_URL} to {LIBRARIES_ZIP_PATH}", xbmc.LOGINFO)
            urllib.request.urlretrieve(LIBRARIES_ZIP_URL, LIBRARIES_ZIP_PATH)
            
            xbmc.log(f"[Acestream Channels] INFO: Libraries downloaded. Attempting to extract to: {LIBRARIES_PATH}", xbmc.LOGINFO)
            with zipfile.ZipFile(LIBRARIES_ZIP_PATH, "r") as zip_ref:
                zip_ref.extractall(LIBRARIES_PATH)
            
            xbmc.log("[Acestream Channels] INFO: Libraries extracted. Removing zip file.", xbmc.LOGINFO)
            os.remove(LIBRARIES_ZIP_PATH)
            xbmcgui.Dialog().notification("Addon", "Bibliotecas instaladas correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.log("[Acestream Channels] INFO: Library installation successful.", xbmc.LOGINFO)
        except Exception as e:
            import traceback
            error_msg = f"[Acestream Channels] ERROR: Critical error during library installation: {str(e)}\n{traceback.format_exc()}"
            xbmc.log(error_msg, xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", "Error crítico al instalar bibliotecas. Consulta el log de Kodi para más detalles.", xbmcgui.NOTIFICATION_ERROR)
            sys.exit()

# Llamar a la función de verificación e instalación de bibliotecas al inicio
check_and_install_libraries()

# Agregar las bibliotecas a sys.path (esto debe hacerse después de que estén instaladas)
sys.path.insert(0, LIBRARIES_PATH)

# Intentar importar los módulos requeridos (requests, BeautifulSoup)
try:
    import requests
    from bs4 import BeautifulSoup
except ImportError as e:
    xbmcgui.Dialog().notification("Error", f"No se pudieron importar los módulos: {e}", xbmcgui.NOTIFICATION_ERROR)
    xbmc.log(f"[Acestream Channels] ERROR: Failed to import modules: {e}", xbmc.LOGERROR)
    sys.exit()


# --- Funciones principales ---

# Función para construir URLs de Kodi
def build_url(query):
    return BASE_URL + '?' + urlencode(query)

# Función para raspar canales de la URL de origen
def scrape_channels_from_url_new(url):
    try:
        response = requests.get(url, timeout=10) # Añadir timeout para evitar cuelgues
        response.raise_for_status() # Lanza una excepción para errores HTTP
        soup = BeautifulSoup(response.text, 'html.parser')

        categorized_channels = {}
        current_category = None
        
        # Diccionario para contar duplicados por categoría
        channel_name_counts = {}

        # Buscar el tbody principal
        tbody = soup.find('tbody')
        if not tbody:
            xbmc.log(f"[Acestream Channels] ERROR: No se encontró el elemento <tbody> en {url}", xbmc.LOGERROR)
            return {}

        rows = tbody.find_all('tr')
        
        # Bandera para empezar a procesar desde "M+ LIGA"
        start_processing = False
        # Bandera para detener el procesamiento después de "OTROS CANALES"
        stop_processing_after_others = False 

        for row in rows:
            if stop_processing_after_others: 
                break

            # Check for category headers
            td_header = row.find('td', {'colspan': '7'})
            if td_header:
                # Look for the span with background-color style for category name
                category_span = td_header.find('span', style=lambda value: value and 'background-color' in value)
                if category_span:
                    category_name = category_span.get_text(strip=True).replace('&nbsp;', ' ').strip()
                    
                    if category_name == "M+ LIGA":
                        start_processing = True
                    
                    if start_processing:
                        current_category = category_name
                        if current_category not in categorized_channels:
                            categorized_channels[current_category] = []
                            # Reiniciar el contador de nombres de canal para cada nueva categoría
                            channel_name_counts = {} 
                        xbmc.log(f"[Acestream Channels] INFO: Found category header: {current_category}", xbmc.LOGINFO)
                    
                    # Activar la bandera para detener el procesamiento DESPUÉS de procesar los canales de "OTROS CANALES"
                    if category_name == "OTROS CANALES":
                        stop_processing_after_others = True


            # Si estamos dentro de una categoría, buscar enlaces de canales
            if start_processing and current_category:
                # Encontrar todos los enlaces acestream en la fila actual
                acestream_links = row.find_all('a', href=lambda href: href and href.startswith('acestream://'))
                
                for link in acestream_links:
                    channel_url = link.get('href', '').strip()
                    acestream_id = channel_url.replace("acestream://", "") # Extraer solo el ID
                    
                    # --- Lógica para obtener el nombre y el icono del canal ---
                    channel_name = ""
                    channel_icon_url = ""

                    img_tag = link.find('img')
                    if img_tag:
                        if img_tag.has_attr('alt'):
                            channel_name = img_tag['alt'].strip()
                        if img_tag.has_attr('src'):
                            # Construir la URL absoluta de la imagen
                            channel_icon_url = urljoin(url, img_tag['src'])
                    
                    # Si el nombre no se encontró en 'alt', intentar de <b> o <span> dentro del enlace
                    if not channel_name:
                        channel_name_element = link.find(['b', 'span']) 
                        if channel_name_element:
                            channel_name = channel_name_element.get_text(strip=True)
                        else:
                            channel_name = link.get_text(strip=True) # Fallback: texto directo del <a>
                    
                    # --- Manejo de nombres duplicados (Opciones) y colores ---
                    display_channel_name_base = channel_name.strip() # Nombre base sin opciones o estados
                    
                    option_part = ""
                    # Contar el nombre base para las opciones
                    if display_channel_name_base in channel_name_counts:
                        channel_name_counts[display_channel_name_base] += 1
                        # Formato: | OPCIÓN X
                        option_part = f" | [COLOR {COLOR_CYAN}]OPCIÓN {channel_name_counts[display_channel_name_base]}[/COLOR]"
                    else:
                        channel_name_counts[display_channel_name_base] = 1 # Inicia el contador
                    
                    # Comprobar el estado y añadir color
                    status_part = ""
                    color_element = link.find(['span', 'font'], style=True) or link.find(['span', 'font'], color=True) or link 
                    
                    if color_element:
                        color_style = color_element.get('style', '')
                        font_color = color_element.get('color')

                        if 'color:#ff8c00;' in color_style or font_color == '#ff8c00': # Originalmente naranja en la web
                            status_part = f" | [COLOR {COLOR_ORANGE}]Canal Eventual[/COLOR]" # Naranja en Kodi
                        elif 'color:#ff0000;' in color_style or font_color == '#ff0000': # Rojo en la web
                            status_part = f" | [COLOR {COLOR_RED}]Canal Caído[/COLOR]" # Rojo en Kodi

                    # Construir el nombre final visible en Kodi
                    full_channel_name = f"{display_channel_name_base}{option_part}{status_part}"
                    
                    # Añadir canal a la categoría actual
                    if current_category:
                        # Asegurarse de que no se añadan canales duplicados por ID (aunque el nombre mostrado pueda ser "Opción X")
                        if not any(c["url"] == acestream_id for c in categorized_channels[current_category]):
                            categorized_channels[current_category].append({
                                "name": full_channel_name, 
                                "url": acestream_id,
                                "icon": channel_icon_url 
                            })
                            xbmc.log(f"[Acestream Channels] INFO: Added channel '{full_channel_name}' with icon '{channel_icon_url}' to category '{current_category}'", xbmc.LOGINFO)
                
        xbmc.log(f"[Acestream Channels] INFO: Scraped {sum(len(v) for v in categorized_channels.values())} channels across {len(categorized_channels)} categories from {url}", xbmc.LOGINFO)
        return categorized_channels
    except requests.exceptions.Timeout:
        xbmcgui.Dialog().notification("Error de Conexión", "La solicitud de la página ha excedido el tiempo de espera.", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[Acestream Channels] ERROR: Timeout accessing URL: {url}", xbmc.LOGERROR)
        return {}
    except requests.exceptions.RequestException as e:
        import traceback
        xbmcgui.Dialog().notification("Error de Red", f"No se pudo acceder a la URL de raspado: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[Acestream Channels] ERROR: Network error during scraping from {url}: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        return {}
    except Exception as e:
        import traceback
        xbmcgui.Dialog().notification("Error de Scrapeo", f"Error al procesar la página: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[Acestream Channels] ERROR: Error during scraping from {url}: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        return {}


# Caché de canales raspados para evitar raspar de nuevo en cada clic de categoría
_cached_categorized_channels = None

def get_categorized_channels_cached():
    global _cached_categorized_channels
    if _cached_categorized_channels is None:
        xbmc.log("[Acestream Channels] INFO: Scraping channels for the first time or cache invalid.", xbmc.LOGINFO)
        _cached_categorized_channels = scrape_channels_from_url_new(SCRAPING_URL)
    else:
        xbmc.log("[Acestream Channels] INFO: Using cached scraped channels.", xbmc.LOGINFO)
    return _cached_categorized_channels

# Listar las categorías en el menú principal
def list_categories():
    # Primero, añade la categoría AGENDA
    agenda_list_item = xbmcgui.ListItem(label="AGENDA")
    agenda_list_item.setArt({"icon": f"{RESOURCES_PATH}/agenda.png", "thumb": f"{RESOURCES_PATH}/agenda.png"})
    agenda_url = build_url({"action": "list_channels", "category": "AGENDA"})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=agenda_url, listitem=agenda_list_item, isFolder=True)

    # Luego, obtiene las categorías raspadas dinámicamente
    dynamic_categories = get_categorized_channels_cached()
    
    # Ordena las categorías alfabéticamente
    sorted_category_names = sorted(dynamic_categories.keys())

    for category_name in sorted_category_names:
        icon_path = f"{RESOURCES_PATH}/default.png" # Icono por defecto

        channels_in_category = dynamic_categories.get(category_name)
        
        if channels_in_category: # Asegurarse de que haya canales en la categoría
            selected_channel_index = 0 # Por defecto: primer canal (índice 0)

            # Ajuste de los nombres de categorías para que coincidan con el raspado si es necesario
            # y selección del índice de canal para el icono
            if category_name in ["M+ VAMOS", "M+ ELLAS"]: 
                selected_channel_index = 5 # Sexto canal (índice 5)
            elif category_name in ["EUROSPORT", "FÓRMULA E", "DEPORTES M+"]:
                selected_channel_index = 1 # Segundo canal (índice 1)
            
            # Comprobar si la lista tiene suficientes elementos para el índice seleccionado
            if len(channels_in_category) > selected_channel_index:
                selected_channel = channels_in_category[selected_channel_index]
                if selected_channel.get("icon"): # Comprobar si la URL del icono existe para ese canal
                    icon_path = selected_channel["icon"]
                else:
                    xbmc.log(f"[Acestream Channels] WARNING: Icono no encontrado para el canal {selected_channel_index+1} en la categoría '{category_name}'. Usando icono por defecto.", xbmc.LOGWARNING)
            else:
                xbmc.log(f"[Acestream Channels] WARNING: No hay suficientes canales en la categoría '{category_name}' para el índice de icono deseado {selected_channel_index}. Usando icono por defecto.", xbmc.LOGWARNING)

        list_item = xbmcgui.ListItem(label=category_name)
        list_item.setArt({"icon": icon_path, "thumb": icon_path}) # Usar icon y thumb para mejor visualización
        url = build_url({"action": "list_channels", "category": category_name})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

# Listar canales para una categoría específica (ahora usa raspado dinámico)
def list_channels(category):
    if category == "AGENDA":
        list_agenda_events()
        return

    all_categorized_channels = get_categorized_channels_cached()
    
    # Obtener los canales para la categoría seleccionada
    channels_to_display = all_categorized_channels.get(category, [])

    if not channels_to_display:
        xbmcgui.Dialog().notification("Canales", f"No se encontraron canales para la categoría: {category}", xbmcgui.NOTIFICATION_INFO)
        # Añade un elemento de marcador de posición si no se encuentran canales
        list_item = xbmcgui.ListItem(label="No se encontraron canales")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False) # Not a folder, not playable
        
    for channel in channels_to_display:
        list_item = xbmcgui.ListItem(label=channel["name"])
        # Establecer la URL del icono si está disponible, de lo contrario usar un icono por defecto
        if channel.get("icon"):
            list_item.setArt({"icon": channel["icon"], "thumb": channel["icon"]})
        else:
            list_item.setArt({"icon": f"{RESOURCES_PATH}/default.png", "thumb": f"{RESOURCES_PATH}/default.png"}) # Icono por defecto para canales sin imagen
        
        url = build_url({"action": "play_acestream", "url": channel["url"]})
        list_item.setInfo("video", {"title": channel["name"]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

# --- Funciones de la AGENDA ---
def obtener_eventos_desde_html():
    url = "https://fr.4everproxy.com/direct/aHR0cHM6Ly9jaXJpYWNvLWxpYXJ0LnZlcmNlbC5hcHAv" # URL del proxy para la agenda
    try:
        response = requests.get(url, timeout=10) # Timeout añadido
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        eventos = []
        tabla_eventos = soup.find('table')
        if not tabla_eventos:
            xbmc.log("[Acestream Channels] ERROR: No se encontró la tabla de eventos en la agenda", xbmc.LOGERROR)
            return []
        for fila in tabla_eventos.find_all('tr')[1:]:
            columnas = fila.find_all('td')
            if len(columnas) >= 5:
                hora = columnas[0].text.strip()
                deporte = columnas[1].text.strip()
                competicion = columnas[2].text.strip()
                evento = columnas[3].text.strip()
                canales_html = columnas[4].find_all('a')
                canales = []
                for canal in canales_html:
                    nombre = canal.text.strip()
                    url_id = canal.get('href').replace("acestream://", "")  # Solo el ID
                    canales.append({"name": nombre, "url": url_id}) # Almacena directamente el ID
                if canales:
                    eventos.append({
                        "hora": hora,
                        "categoria": deporte,
                        "evento": evento,
                        "enlaces": canales
                    })
        xbmc.log(f"[Acestream Channels] INFO: Se encontraron {len(eventos)} eventos en la agenda", xbmc.LOGINFO)
        return eventos
    except requests.exceptions.Timeout:
        xbmcgui.Dialog().notification("Error AGENDA", "La solicitud de la agenda ha excedido el tiempo de espera.", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[Acestream Channels] ERROR: Timeout accessing Agenda URL: {url}", xbmc.LOGERROR)
        return []
    except requests.exceptions.RequestException as e:
        import traceback
        xbmcgui.Dialog().notification("Error AGENDA", f"No se pudo acceder a la URL de la agenda: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[Acestream Channels] ERROR: Network error getting Agenda: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        return []
    except Exception as e:
        import traceback
        xbmcgui.Dialog().ok("Error AGENDA", str(e))
        xbmc.log(f"[Acestream Channels] ERROR: Error al obtener eventos de la agenda: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        return []

def list_agenda_events():
    eventos = obtener_eventos_desde_html()
    if not eventos:
        xbmcgui.Dialog().notification("Agenda", "No hay eventos disponibles", xbmcgui.NOTIFICATION_INFO)
        # Añade un elemento de marcador de posición si no hay eventos
        list_item = xbmcgui.ListItem(label="No hay eventos disponibles")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
        return
    for evento in eventos:
        titulo = f"{evento['hora']} | {evento['categoria']} | {evento['evento']}"
        list_item = xbmcgui.ListItem(label=titulo)
        url = build_url({"action": "mostrar_enlaces_evento", "enlaces": json.dumps(evento["enlaces"])})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def mostrar_enlaces_evento(enlaces):
    enlaces = json.loads(enlaces)
    for enlace in enlaces:
        list_item = xbmcgui.ListItem(label=enlace["name"])
        # Asegurarse de que `enlace["url"]` ya contenga solo el ID de `obtener_eventos_desde_html`
        url = build_url({"action": "play_acestream", "url": enlace["url"]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

# --- Funciones de reproducción ---
def play_html5(url):
    try:
        xbmc.Player().play(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def play_acestream(url_id): 
    try:
        # El 'url_id' pasado aquí ya debería ser solo el ID, según lo aseguran las funciones de raspado.
        horus_url = f"plugin://script.module.horus/?action=play&id={url_id}"
        xbmc.Player().play(horus_url)
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"Error al reproducir: {e}", xbmcgui.NOTIFICATION_ERROR)

# --- Punto de entrada del addon ---
if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get("action")
    if action == "list_channels":
        category = args.get("category")
        if category == "AGENDA":
            list_agenda_events()
        else:
            list_channels(category)
    elif action == "mostrar_enlaces_evento":
        mostrar_enlaces_evento(args["enlaces"])
    elif action == "play_html5":
        play_html5(args["url"])
    elif action == "play_acestream":
        play_acestream(args["url"]) 
    else:
        list_categories()