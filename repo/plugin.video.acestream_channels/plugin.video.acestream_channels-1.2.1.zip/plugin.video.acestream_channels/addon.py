import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.request
import zipfile
import json
from urllib.parse import urlencode, parse_qsl
import xbmcvfs
import datetime # Importar el módulo datetime

# Configuración para la gestión de dependencias
LIBRARIES_ZIP_URL = "https://github.com/Gunter257/repoachannels/raw/refs/heads/main/bibliotecas.zip" # URL actualizada
LIBRARIES_ZIP_PATH = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'bibliotecas.zip')
LIBRARIES_PATH = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'lib')

# Ubicación del archivo de primer inicio en el directorio de perfil del addon
ADDON = xbmcaddon.Addon()
FIRST_RUN_FILE = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), "first_run.txt") # Uso de xbmcvfs.translatePath

# Define el handle del addon
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Obtener la ruta del addon
addon_path = ADDON.getAddonInfo('path')
RESOURCES_PATH = os.path.join(addon_path, 'resources')

# Funciones de utilidad
def build_url(query):
    return BASE_URL + '?' + urlencode(query)

# Verificar e instalar bibliotecas si es la primera ejecución
def check_and_install_libraries():
    if not os.path.exists(LIBRARIES_PATH):
        xbmcgui.Dialog().notification("Instalando bibliotecas", "Descargando bibliotecas necesarias...", xbmcgui.NOTIFICATION_INFO)
        try:
            # Descargar el archivo ZIP
            urllib.request.urlretrieve(LIBRARIES_ZIP_URL, LIBRARIES_ZIP_PATH)
            xbmc.log(f"[Acestream Channels] INFO: Attempting to download libraries from: {LIBRARIES_ZIP_URL} to {LIBRARIES_ZIP_PATH}", xbmc.LOGINFO)

            # Extraer el contenido
            with zipfile.ZipFile(LIBRARIES_ZIP_PATH, 'r') as zip_ref:
                zip_ref.extractall(LIBRARIES_PATH)
            xbmc.log(f"[Acestream Channels] INFO: Libraries downloaded. Attempting to extract to: {LIBRARIES_PATH}", xbmc.LOGINFO)

            # Eliminar el archivo ZIP después de la extracción
            os.remove(LIBRARIES_ZIP_PATH)
            xbmc.log("[Acestream Channels] INFO: Libraries extracted. Removing zip file.", xbmc.LOGINFO)

            # Crear el archivo de "primera ejecución"
            with open(FIRST_RUN_FILE, "w") as f:
                f.write("True")

            xbmcgui.Dialog().notification("Instalación completa", "Bibliotecas instaladas correctamente.", xbmcgui.NOTIFICATION_INFO)
            xbmc.log("[Acestream Channels] INFO: Library installation successful.", xbmc.LOGINFO)

        except Exception as e:
            xbmcgui.Dialog().notification("Error de instalación", f"No se pudieron instalar las bibliotecas: {e}", xbmcgui.NOTIFICATION_ERROR)
            xbmc.log(f"[Acestream Channels] ERROR: Failed to install libraries: {e}", xbmc.LOGERROR)
            # Considerar qué hacer si la instalación falla (ej. salir del addon)

# Funciones de actualización del addon
def check_for_updates_on_startup():
    xbmc.log("[Acestream Channels] INFO: Starting update check.", xbmc.LOGINFO)
    
    last_check_str = ADDON.getSetting('last_update_check') 
    
    last_check_time = None
    if last_check_str:
        try:
            last_check_time = datetime.datetime.strptime(last_check_str, "%Y-%m-%d %H:%M:%S.%f")
        except ValueError:
            # Si el formato es inválido (ej. al principio o si se corrompió), se reinicia la marca de tiempo
            xbmc.log("[Acestream Channels] WARNING: Invalid last_update_check format. Resetting.", xbmc.LOGWARNING)
            last_check_time = None 

    current_time = datetime.datetime.now()
    
    # Define el intervalo de tiempo para la comprobación de actualizaciones (en segundos)
    # 3600 segundos = 1 hora
    UPDATE_INTERVAL_SECONDS = 3600 

    if last_check_time and (current_time - last_check_time).total_seconds() < UPDATE_INTERVAL_SECONDS:
        xbmc.log(f"[Acestream Channels] INFO: Skipping update check. Last check was {(current_time - last_check_time).total_seconds() / 3600:.2f} hours ago.", xbmc.LOGINFO)
        return

    # Si ha pasado suficiente tiempo o es la primera vez, guarda la nueva marca de tiempo
    ADDON.setSetting('last_update_check', current_time.strftime("%Y-%m-%d %H:%M:%S.%f"))
    xbmc.log("[Acestream Channels] INFO: Performed update check.", xbmc.LOGINFO)

    # TODO: Aquí es donde añadirías la lógica para comprobar si hay una nueva versión del addon en GitHub
    # Por ejemplo:
    # 1. Descargar el addon.xml remoto de tu repositorio.
    # 2. Parsear la versión remota.
    # 3. Comparar con la versión actual de tu addon (ADDON.getAddonInfo('version')).
    # 4. Si la versión remota es mayor, notificar al usuario y/o sugerir la actualización.


# Funciones para listar contenido
def list_channels(category=None):
    xbmcplugin.setPluginCategory(addon_handle, category if category else 'Canales AceStream')
    
    # Ejemplo de cómo podrías cargar canales de un archivo JSON
    # Puedes tener un JSON para cada categoría o uno general con categorías dentro
    json_file_path = os.path.join(RESOURCES_PATH, 'canales.json') 
    
    channels_data = []
    if os.path.exists(json_file_path):
        with open(json_file_path, 'r', encoding='utf-8') as f:
            full_data = json.load(f)
            if category and category in full_data:
                channels_data = full_data[category]
            elif not category: # Si no hay categoría, muestra todos o un subconjunto predeterminado
                # Aquí podrías decidir si quieres mostrar una lista plana de todos los canales
                # o forzar al usuario a seleccionar una categoría primero (usando list_categories)
                pass # Por ahora, no haremos nada si no hay categoría y no está en full_data
    
    for channel in channels_data:
        name = channel.get("name", "Nombre Desconocido")
        acestream_id = channel.get("acestream_id")
        
        if acestream_id:
            list_item = xbmcgui.ListItem(label=name)
            # Aquí la acción es reproducir directamente
            url = build_url({"action": "play_acestream", "url": acestream_id})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
        else:
            xbmc.log(f"[Acestream Channels] WARNING: Channel '{name}' has no acestream_id.", xbmc.LOGWARNING)

    xbmcplugin.endOfDirectory(addon_handle)

def list_agenda_events():
    xbmcplugin.setPluginCategory(addon_handle, 'Agenda')
    # Ejemplo de agenda, esto se llenaría con tus datos reales
    agenda_data = [
        {"name": "Evento 1 (Acestream)", "url": "acestream://tu_id_acestream_1"},
        {"name": "Evento 2 (HTML5)", "url": "http://ejemplo.com/stream.m3u8"},
    ]

    for item in agenda_data:
        list_item = xbmcgui.ListItem(label=item["name"])
        if item["url"].startswith("acestream://"):
            url = build_url({"action": "play_acestream", "url": item["url"]})
            list_item.setProperty('IsPlayable', 'true')
        else:
            url = build_url({"action": "play_html5", "url": item["url"]})
            list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

# --- Nueva función para listar las categorías principales ---
CATEGORIES = ["AGENDA", "DEPORTES", "NOTICIAS", "MUSICA", "PELICULAS", "DOCUMENTALES", "INFANTILES", "ANIME"] # Define tus categorías

def list_categories():
    xbmcplugin.setPluginCategory(addon_handle, 'AceStream Channels') # Nombre que aparecerá en la interfaz
    for category in CATEGORIES:
        list_item = xbmcgui.ListItem(label=category)
        url = build_url({"action": "list_channels", "category": category})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


# --- Funciones de reproducción (sin cambios sustanciales, solo corregidas si hubo errores) ---
def play_html5(url):
    try:
        xbmc.Player().play(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def play_acestream(url_id): # Renombrado 'url' a 'url_id' para mayor claridad
    try:
        # El 'url_id' pasado aquí ya debería ser solo el ID, o estar en formato acestream://ID
        # Si viene en formato acestream://ID, extraer solo el ID
        if url_id.startswith("acestream://"):
            acestream_id = url_id.replace("acestream://", "")
        else:
            acestream_id = url_id # Asumir que ya es solo el ID

        horus_url = f"plugin://script.module.horus/?action=play&id={acestream_id}"
        xbmc.Player().play(horus_url)
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"Error al reproducir: {e}", xbmcgui.NOTIFICATION_ERROR)


# --- Punto de entrada del addon ---
if __name__ == '__main__':
    # Estas funciones se ejecutan cada vez que el addon se inicia
    check_and_install_libraries()
    check_for_updates_on_startup()

    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get("action")

    if action == "list_channels":
        category = args.get("category")
        if category == "AGENDA":
            list_agenda_events()
        else:
            list_channels(category)
    elif action == "play_html5":
        url = args.get("url")
        play_html5(url)
    elif action == "play_acestream":
        url_id = args.get("url") 
        play_acestream(url_id)
    # Puedes añadir más 'elif' para otras acciones que definas en tu addon
    # elif action == "otra_accion":
    #    otra_funcion()
    
    else: # Si no se especifica ninguna acción (ej. cuando el usuario abre el addon por primera vez)
        list_categories() # Llama a la nueva función para mostrar el menú principal