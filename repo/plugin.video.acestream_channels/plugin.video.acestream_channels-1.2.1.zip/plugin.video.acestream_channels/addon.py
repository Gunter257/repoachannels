import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.request
import zipfile
import json
from urllib.parse import urlencode, parse_qsl
import xbmcvfs
import xml.etree.ElementTree as ET # Necesario para parsear XML

# Configuración para la gestión de dependencias
LIBRARIES_ZIP_URL = "https://github.com/Gunter257/repoachannels/raw/refs/heads/main/bibliotecas.zip"
LIBRARIES_ZIP_PATH = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'bibliotecas.zip')
LIBRARIES_PATH = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'lib')

# Ubicación del archivo de primer inicio en el directorio de perfil del addon
ADDON = xbmcaddon.Addon()
FIRST_RUN_FILE = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), "first_run.txt")

# Define el handle del addon
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Obtener la ruta del addon
addon_path = ADDON.getAddonInfo('path')
RESOURCES_PATH = os.path.join(addon_path, 'resources')

# --- NUEVO: Configuración para la comprobación de actualizaciones ---
REPOSITORY_ADDONS_XML_URL = "https://raw.githubusercontent.com/Gunter257/repoachannels/main/addons.xml"
ADDON_ID = ADDON.getAddonInfo('id')
LAST_UPDATE_CHECK_FILE = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), "last_update_check.txt")
CHECK_INTERVAL_HOURS = 24 # Comprobar actualizaciones cada 24 horas

# Resto de tu código (sin cambios hasta la función `check_and_install_libraries`)
# ...

def check_and_install_libraries():
    if not os.path.exists(LIBRARIES_PATH):
        xbmcgui.Dialog().notification("Instalando bibliotecas", "Descargando bibliotecas necesarias...", xbmcgui.NOTIFICATION_INFO)
        try:
            xbmc.log(f"[Acestream Channels] INFO: Attempting to download libraries from: {LIBRARIES_ZIP_URL} to {LIBRARIES_ZIP_PATH}", xbmc.LOGINFO)
            urllib.request.urlretrieve(LIBRARIES_ZIP_URL, LIBRARIES_ZIP_PATH)
            
            xbmc.log(f"[Acestream Channels] INFO: Libraries downloaded. Attempting to extract to: {LIBRARIES_PATH}", xbmc.LOGINFO)
            with zipfile.ZipFile(LIBRARIES_ZIP_PATH, "r") as zip_ref:
                zip_ref.extractall(LIBRARIES_PATH)
            
            xbmc.log("[Acestream Channels] INFO: Libraries extracted. Removing zip file.", xbmc.LOGINFO)
            os.remove(LIBRARIES_ZIP_PATH)
            xbmcgui.Dialog().notification("Addon", "Bibliotecas instaladas correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.log("[Acestream Channels] INFO: Library installation successful.", xbmc.LOGINFO)
        except Exception as e:
            import traceback
            error_msg = f"[Acestream Channels] ERROR: Critical error during library installation: {str(e)}\n{traceback.format_exc()}"
            xbmc.log(error_msg, xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", "Error crítico al instalar bibliotecas. Consulta el log de Kodi para más detalles.", xbmcgui.NOTIFICATION_ERROR)
            sys.exit()

def verificar_prime_inicio():
    profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir)
        
    if not os.path.exists(FIRST_RUN_FILE):
        check_and_install_libraries()
        with open(FIRST_RUN_FILE, "w") as f:
            f.write("Primer inicio completado")

# Llamar a la función de verificación de primer inicio (antes de importar requests/bs4 si dependen de las libs)
verificar_prime_inicio()

# Agregar las bibliotecas a sys.path
sys.path.insert(0, LIBRARIES_PATH)

# Intentar importar los módulos requeridos (requests, BeautifulSoup)
try:
    import requests
    from bs4 import BeautifulSoup
    import datetime # NUEVO: Para gestionar la fecha de la última comprobación
except ImportError as e:
    xbmcgui.Dialog().notification("Error", f"No se pudieron importar los módulos: {e}", xbmcgui.NOTIFICATION_ERROR)
    sys.exit()


# --- NUEVA FUNCIÓN: Comprobar actualizaciones al iniciar ---
def check_for_updates_on_startup():
    xbmc.log(f"[Acestream Channels] INFO: Starting update check.", xbmc.LOGINFO)
    
    # Comprobar si ha pasado suficiente tiempo desde la última verificación
    current_time = datetime.datetime.now()
    if xbmcvfs.exists(LAST_UPDATE_CHECK_FILE):
        with open(LAST_UPDATE_CHECK_FILE, "r") as f:
            last_check_str = f.read()
        try:
            last_check_time = datetime.datetime.strptime(last_check_str, "%Y-%m-%d %H:%M:%S.%f")
            time_since_last_check = current_time - last_check_time
            if time_since_last_check < datetime.timedelta(hours=CHECK_INTERVAL_HOURS):
                xbmc.log(f"[Acestream Channels] INFO: Skipping update check. Last check was {time_since_last_check.total_seconds() / 3600:.2f} hours ago.", xbmc.LOGINFO)
                return # No ha pasado suficiente tiempo, salir
        except ValueError:
            xbmc.log(f"[Acestream Channels] WARNING: Could not parse last update check time: {last_check_str}. Performing check.", xbmc.LOGWARNING)
    
    # Actualizar el archivo de última comprobación
    with open(LAST_UPDATE_CHECK_FILE, "w") as f:
        f.write(str(current_time))

    try:
        # Obtener la versión actual instalada
        current_version = ADDON.getAddonInfo('version')
        xbmc.log(f"[Acestream Channels] INFO: Current installed version: {current_version}", xbmc.LOGINFO)

        # Descargar el addons.xml del repositorio
        response = requests.get(REPOSITORY_ADDONS_XML_URL, timeout=10)
        response.raise_for_status()
        root = ET.fromstring(response.text)

        latest_version = None
        for addon_element in root.findall('addon'):
            addon_id_repo = addon_element.get('id')
            addon_version_repo = addon_element.get('version')

            if addon_id_repo == ADDON_ID:
                if latest_version is None or compare_versions(addon_version_repo, latest_version) > 0:
                    latest_version = addon_version_repo

        if latest_version and compare_versions(latest_version, current_version) > 0:
            xbmc.log(f"[Acestream Channels] INFO: New version available: {latest_version}", xbmc.LOGINFO)
            # Hay una nueva versión disponible, mostrar diálogo al usuario
            dialog = xbmcgui.Dialog()
            should_update = dialog.yesno(
                ADDON.getAddonInfo('name'), # Título del diálogo (nombre del addon)
                f"Hay una nueva versión disponible: [B]{latest_version}[/B]\n"
                f"Tu versión actual es: [B]{current_version}[/B]\n\n"
                f"¿Quieres actualizar ahora?",
                yeslabel="Actualizar",
                nolabel="Ahora no"
            )

            if should_update:
                xbmc.log("[Acestream Channels] INFO: User accepted update. Triggering Kodi update.", xbmc.LOGINFO)
                # Ejecutar un comando interno de Kodi para actualizar el addon
                # Esto es como si fueras a "Buscar actualizaciones" en la info del addon
                xbmc.executebuiltin(f'UpdateAddon({ADDON_ID})')
                xbmcgui.Dialog().notification(ADDON.getAddonInfo('name'), "Actualización iniciada. Revisa tus notificaciones de Kodi.", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmc.log("[Acestream Channels] INFO: User declined update.", xbmc.LOGINFO)
        else:
            xbmc.log("[Acestream Channels] INFO: Addon is up to date or no newer version found.", xbmc.LOGINFO)

    except requests.exceptions.RequestException as e:
        xbmc.log(f"[Acestream Channels] ERROR: Network error checking for updates: {e}", xbmc.LOGERROR)
        # xbmcgui.Dialog().notification("Error de Actualización", "No se pudo comprobar si hay actualizaciones (problema de red).", xbmcgui.NOTIFICATION_ERROR)
    except ET.ParseError as e:
        xbmc.log(f"[Acestream Channels] ERROR: XML parsing error checking for updates: {e}", xbmc.LOGERROR)
        # xbmcgui.Dialog().notification("Error de Actualización", "Error al leer el archivo de actualizaciones del repositorio.", xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        import traceback
        xbmc.log(f"[Acestream Channels] ERROR: Unexpected error during update check: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        # xbmcgui.Dialog().notification("Error de Actualización", "Ocurrió un error inesperado al buscar actualizaciones.", xbmcgui.NOTIFICATION_ERROR)

# Función de ayuda para comparar versiones (ej. "1.1.0" vs "1.2.0")
# Devuelve > 0 si v1 es mayor que v2, < 0 si v1 es menor que v2, 0 si son iguales
def compare_versions(v1, v2):
    def normalize(v):
        return [int(x) for x in v.split('.')]
    return sum(map(lambda x, y: (x > y) - (x < y), normalize(v1), normalize(v2)))


# --- Resto de tu código (sin cambios, a partir de SCRAPING_URL) ---

SCRAPING_URL = "https://www.socialcreator.com/xupimarc2/?s=289267"

# ... (todo lo demás de tu addon.py)

# --- Punto de entrada del addon ---
if __name__ == '__main__':
    # Llamar a la función de comprobación de actualizaciones
    check_for_updates_on_startup() # <--- ¡Añadir esta línea aquí!

    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get("action")
    if action == "list_channels":
        category = args.get("category")
        if category == "AGENDA":
            list_agenda_events()
        else:
            list_channels(category)
    elif action == "mostrar_enlaces_evento":
        mostrar_enlaces_evento(args["enlaces"])
    elif action == "play_html5":
        play_html5(args["url"])
    elif action == "play_acestream":
        play_acestream(args["url"]) # 'url' en args será el ID
    else:
        list_categories()