import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.request
import zipfile
import json
import re 
from urllib.parse import urlencode, parse_qsl, quote
import xbmcvfs

# --- CONFIGURACIÓN GENERAL ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# --- CONFIGURACIÓN DE DEPENDENCIAS ---
LIBRARIES_ZIP_URL = "https://github.com/Gunter257/repoachannels/raw/refs/heads/main/bibliotecas.zip"
LIBRARIES_ZIP_PATH = os.path.join(PROFILE_PATH, 'bibliotecas.zip') 
LIBRARIES_PATH = os.path.join(PROFILE_PATH, 'lib') 

# --- IMÁGENES Y COLORES ---
addon_path = ADDON.getAddonInfo('path')
ICON_AGENDA = os.path.join(addon_path, 'resources', 'agenda.png')

COLOR_ORANGE = "FF00A5FF"
COLOR_RED = "FFFF0000"
COLOR_CYAN = "FF00FFFF"
COLOR_BLUE = "FF0000FF"
COLOR_GREEN = "FF00FF00"
COLOR_YELLOW = "FFFFFF00"
COLOR_WHITE = "FFFFFFFF"
COLOR_TIME = "FF87CEEB" 
COLOR_SPORT_CATEGORY = "FF32CD32" 
COLOR_EVENT_DETAILS = "FFFFFFFF" 

# --- LISTA DE URLs DE AGENDA (Principal + Respaldos) ---
# El addon probará en orden. Si la 1 falla, va a la 2, etc.
AGENDA_URLS = [
    "https://eventos-eight-dun.vercel.app/",  # PRINCIPAL (Nueva)
    "https://eventos-eight-dun.vercel.app/index.html",      # <--- PEGA AQUÍ TU URL ANTIGUA 1
    "https://eventos-uvl7.vercel.app/"       # <--- PEGA AQUÍ TU URL ANTIGUA 2
]

# --- CHANGELOG ---
CHANGELOG = {
    "1.2.5": [
        "Sistema Multi-Fuente: Soporte para URLs de respaldo.",
        "Anti-Bloqueo aplicado a todas las fuentes de agenda.",
        "Mayor robustez ante caídas de servidor."
    ]
}

addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# --- INICIALIZACIÓN ---
try:
    ADDON.setSetting('addon_initialized_test', 'true')
except Exception as e:
    xbmc.log(f"[{ADDON_NAME}] ERROR: Failed to save initial setting: {e}", xbmc.LOGERROR)

def check_and_install_libraries():
    if not os.path.exists(LIBRARIES_PATH):
        xbmc.log(f"[{ADDON_NAME}] INFO: Library folder not found. Starting download...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Descargando...", "Descargando librerías necesarias...", xbmcgui.NOTIFICATION_INFO)
        try:
            if not os.path.exists(PROFILE_PATH):
                os.makedirs(PROFILE_PATH)
            urllib.request.urlretrieve(LIBRARIES_ZIP_URL, LIBRARIES_ZIP_PATH)
            with zipfile.ZipFile(LIBRARIES_ZIP_PATH, 'r') as zip_ref:
                zip_ref.extractall(LIBRARIES_PATH)
            os.remove(LIBRARIES_ZIP_PATH)
        except Exception as e:
            return False
    return True

if check_and_install_libraries():
    sys.path.insert(0, LIBRARIES_PATH)
    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError as e:
        sys.exit()
else:
    sys.exit()

# --- FUNCIONES DE UTILIDAD ---

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def clean_text(text):
    if not text: return ""
    return re.sub(r'\s+', ' ', text).strip()

def get_acestream_id(url):
    if url.startswith("acestream://"):
        return url.replace("acestream://", "")
    return url

def check_updates():
    last_version = ADDON.getSetting('last_run_version')
    if last_version != ADDON_VERSION:
        changes = CHANGELOG.get(ADDON_VERSION)
        if changes:
            text = f"[B]Novedades de la versión {ADDON_VERSION}:[/B]\n\n"
            for item in changes:
                text += f"- {item}\n"
            dialog = xbmcgui.Dialog()
            dialog.ok(f"{ADDON_NAME} - Actualizado", text)
        ADDON.setSetting('last_run_version', ADDON_VERSION)

# --- SISTEMA DE CONEXIÓN INTELIGENTE ---

def fetch_html_content(target_url):
    """
    Intenta obtener el HTML usando Directo -> AllOrigins -> CorsProxy
    """
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
    
    # 1. Intento Directo
    try:
        xbmc.log(f"[{ADDON_NAME}] Conectando directo a: {target_url}", xbmc.LOGINFO)
        r = requests.get(target_url, headers=headers, timeout=10)
        if r.status_code == 200: return r.text
    except: pass
    
    # 2. Intento AllOrigins
    try:
        xbmc.log(f"[{ADDON_NAME}] Usando Proxy 1 para: {target_url}", xbmc.LOGINFO)
        proxy_url = f"https://api.allorigins.win/get?url={quote(target_url)}"
        r = requests.get(proxy_url, headers=headers, timeout=15)
        if r.status_code == 200:
            data = r.json()
            if 'contents' in data and data['contents']: return data['contents']
    except: pass

    # 3. Intento CorsProxy
    try:
        xbmc.log(f"[{ADDON_NAME}] Usando Proxy 2 para: {target_url}", xbmc.LOGINFO)
        proxy_url = f"https://corsproxy.io/?{quote(target_url)}"
        r = requests.get(proxy_url, headers=headers, timeout=15)
        if r.status_code == 200: return r.text
    except: pass

    return None

def parse_events_from_html(html_content):
    """
    Extrae los eventos del HTML. Devuelve una lista de items o None si falla.
    """
    items_found = []
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Intentamos buscar tabla (Formato Nuevo)
        table = soup.find('table')
        if table:
            rows = table.find_all('tr')
            for row in rows:
                cols = row.find_all('td')
                if not cols or len(cols) < 6: continue 

                # Extracción segura de datos
                try:
                    time = clean_text(cols[1].get_text())
                    sport = clean_text(cols[2].get_text())
                    competition = clean_text(cols[3].get_text())
                    event_name = clean_text(cols[4].get_text())
                    links_col = cols[5]
                    
                    title_display = f"[COLOR {COLOR_TIME}][{time}][/COLOR] [COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] {event_name} [I]({competition})[/I]"
                    
                    links = []
                    for link in links_col.find_all('a'):
                        href = link.get('href', '')
                        if 'acestream://' in href:
                            ace_id = get_acestream_id(href)
                            name = clean_text(link.get_text()).replace('▶', '').strip()
                            links.append({'name': name, 'id': ace_id})
                    
                    if links:
                        items_found.append({
                            'title': title_display,
                            'event_name': event_name,
                            'competition': competition,
                            'links': links
                        })
                except: continue
        
        # AQUI PODRÍAMOS AÑADIR OTRO FORMATO DE PARSEO PARA LAS URLs ANTIGUAS
        # Si no encuentra tabla, busca listas (li), etc.
        
        return items_found
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error parsing HTML: {e}", xbmc.LOGERROR)
        return None

# --- LÓGICA DE LA AGENDA ---

def list_agenda_events():
    events_found = False
    
    # Recorremos la lista de URLs (Principal -> Respaldo 1 -> Respaldo 2)
    for i, url in enumerate(AGENDA_URLS):
        if not url or "tu-url" in url: continue # Saltar placeholders vacíos
        
        xbmcgui.Dialog().notification("Agenda", f"Probando servidor {i+1}...", xbmcgui.NOTIFICATION_INFO, 1000)
        
        html = fetch_html_content(url)
        if html:
            items = parse_events_from_html(html)
            if items and len(items) > 0:
                # ¡Éxito! Hemos encontrado eventos
                events_found = True
                
                for item in items:
                    links = item['links']
                    event_name = item['event_name']
                    competition = item['competition']
                    title_display = item['title']

                    if len(links) == 1:
                        ace_id = links[0]['id']
                        url_item = build_url({'action': 'play_channel', 'id': ace_id})
                        li = xbmcgui.ListItem(label=title_display)
                        li.setInfo('video', {'title': event_name, 'mediatype': 'video', 'plot': competition})
                        li.setProperty('IsPlayable', 'true')
                        li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'}) 
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_item, listitem=li, isFolder=False)
                    else:
                        links_json = json.dumps(links)
                        url_item = build_url({'action': 'list_event_links', 'links': links_json, 'title': event_name})
                        title_display += f" [COLOR {COLOR_YELLOW}]({len(links)} Canales)[/COLOR]"
                        li = xbmcgui.ListItem(label=title_display)
                        li.setInfo('video', {'title': event_name, 'plot': f"Competición: {competition}\nOpciones disponibles: {len(links)}"})
                        li.setArt({'icon': 'DefaultFolder.png'})
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_item, listitem=li, isFolder=True)
                
                break # Salimos del bucle de URLs, ya tenemos la agenda
            else:
                xbmc.log(f"[{ADDON_NAME}] URL {url} descargada pero sin eventos reconocibles.", xbmc.LOGWARNING)
    
    if events_found:
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcgui.Dialog().notification("Error", "No se pudo obtener la agenda de ninguna fuente.", xbmc.NOTIFICATION_ERROR)

def list_event_links(links_json, event_title):
    try:
        links = json.loads(links_json)
        xbmcplugin.setContent(addon_handle, 'videos')
        for link in links:
            name = link['name']
            ace_id = link['id']
            display_name = f"[COLOR {COLOR_GREEN}]Ver en:[/COLOR] {name}"
            url = build_url({'action': 'play_channel', 'id': ace_id})
            li = xbmcgui.ListItem(label=display_name)
            li.setInfo('video', {'title': event_title, 'mediatype': 'video'})
            li.setProperty('IsPlayable', 'true')
            li.setArt({'icon': 'DefaultVideo.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] ERROR Listing Event Links: {e}", xbmc.LOGERROR)

def play_channel(url_id):
    try:
        xbmc.log(f"[{ADDON_NAME}] INFO: Intentando reproducir ID: {url_id}", xbmc.LOGINFO)
        use_external = ADDON.getSetting('use_external_player') == 'true'
        if use_external:
            strm_content = f"http://127.0.0.1:6878/ace/getstream?id={url_id}"
            strm_path = os.path.join(PROFILE_PATH, 'temp_acestream.strm')
            with open(strm_path, 'w') as f:
                f.write(strm_content)
            xbmc.Player().play(strm_path)
        else:
            horus_url = f"plugin://script.module.horus/?action=play&id={url_id}"
            li = xbmcgui.ListItem(path=horus_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, li)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] ERROR: Error al reproducir AceStream: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", f"Error al reproducir: {e}", xbmc.NOTIFICATION_ERROR)

# --- RUTEO PRINCIPAL ---
if __name__ == '__main__':
    check_updates()
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get("action")
    
    if action is None:
        url = build_url({'action': 'list_channels', 'category': 'AGENDA'})
        li = xbmcgui.ListItem(label="[B]AGENDA DEPORTIVA[/B]")
        li.setArt({'icon': ICON_AGENDA, 'thumb': ICON_AGENDA})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)

    elif action == "list_channels":
        category = args.get("category")
        if category == "AGENDA":
            list_agenda_events()

    elif action == "list_event_links":
        links = args.get("links")
        title = args.get("title")
        list_event_links(links, title)

    elif action == "play_channel":
        url_id = args.get("id")
        play_channel(url_id)